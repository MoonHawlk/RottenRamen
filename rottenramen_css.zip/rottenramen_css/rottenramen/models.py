from rottenramen import database, login_manager
from datetime import datetime
from flask_login import UserMixin


@login_manager.user_loader
def load_user(id_user):
    return User.query.get(int(id_user))


class User(database.Model, UserMixin):
    id = database.Column(database.Integer, primary_key=True)
    username = database.Column(database.String, nullable=False, unique=True)
    email = database.Column(database.String, nullable=False, unique=True)
    password = database.Column(database.String, nullable=False)
    profile_photo = database.Column(database.String, default='default.jpg')
    posts = database.relationship('Post', backref='author', lazy=True)
    animes = database.relationship('Anime', backref='creator', lazy=True)
    episodes = database.relationship('Episode', backref='creator_episode', lazy=True)

    def count_posts(self):
        return len(self.posts)

    def count_animes(self):
        return len(self.animes)


class Post(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    title = database.Column(database.String, nullable=False)
    body = database.Column(database.Text, nullable=False)
    date_post = database.Column(database.DateTime, nullable=False, default=datetime.utcnow)
    id_user = database.Column(database.Integer, database.ForeignKey('user.id'), nullable=False)
    id_episode = database.Column(database.Integer, database.ForeignKey('episode.id'), nullable=False)


class Anime(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    name = database.Column(database.String, nullable=False, unique=True)
    synopsis = database.Column(database.Text, nullable=False)
    anime_photo = database.Column(database.String, nullable=False)
    id_anime = database.Column(database.Integer, database.ForeignKey('user.id'), nullable=False)


class Episode(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    name = database.Column(database.String, nullable=False, unique=True)
    classification = database.Column(database.String, nullable=False)
    synopsis = database.Column(database.Text, nullable=False)
    episode_photo = database.Column(database.String, nullable=False)
    id_episode = database.Column(database.Integer, database.ForeignKey('user.id'), nullable=False)

