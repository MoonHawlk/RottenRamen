from flask import render_template, redirect, url_for, request, flash, abort
from rottenramen import app, database, bcrypt
from rottenramen.forms import FormLogin, FormCreatAccount, FormEditProfile, FormCreatPost, FormCreatAnime, FormCreatEpisode
from rottenramen.models import User, Post, Anime, Episode
from flask_login import login_user, logout_user, current_user, login_required
import secrets
import os
from PIL import Image


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form_login = FormLogin()
    if form_login.validate_on_submit() and 'button_submit_login' in request.form:
        user = User.query.filter_by(email=form_login.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form_login.password.data):
            login_user(user, remember=form_login.remember_data.data)
            flash(f'Login feito com sucesso no e-mail: {form_login.email.data}', 'alert-success')
            par_next = request.args.get('next')
            if par_next:
                return redirect(par_next)
            else:
                return redirect(url_for('home'))
        else:
            flash('Falha no login. E-mail ou Senha Incorretos', 'alert-danger')
    return render_template('login.html', form_login=form_login)


@app.route('/cadastro', methods=['GET', 'POST'])
def register():
    form_creataccount = FormCreatAccount()
    if form_creataccount.validate_on_submit() and 'button_submit_creataccount' in request.form:
        password_crypt = bcrypt.generate_password_hash(form_creataccount.password.data)
        user = User(username=form_creataccount.username.data, email=form_creataccount.email.data, password=password_crypt)
        database.session.add(user)
        database.session.commit()
        flash(f'Conta criada para o e-mail: {form_creataccount.email.data}', 'alert-success')
        return redirect(url_for('home'))
    return render_template('register.html', form_creataccount=form_creataccount)


@app.route('/sair')
@login_required
def logout():
    logout_user()
    flash(f'Logout Feito com Sucesso', 'alert-success')
    return redirect(url_for('home'))


@app.route('/perfil')
@login_required
def profile():
    profile_photo = url_for('static', filename=f'profile_photos/{current_user.profile_photo}')
    return render_template('profile.html', profile_photo=profile_photo)


def save_image(image):
    code = secrets.token_hex(8)
    name, extension = os.path.splitext(image.filename)
    file_name = name + code + extension
    full_path = os.path.join(app.root_path, 'static/profile_photos', file_name)
    size = (400, 400)
    reduced_image = Image.open(image)
    reduced_image.thumbnail(size)
    reduced_image.save(full_path)
    return file_name


@app.route('/perfil/editar', methods=['GET', 'POST'])
@login_required
def edit_profile():
    form = FormEditProfile()
    if form.validate_on_submit():
        current_user.username = form.username.data
        current_user.email = form.email.data
        if form.profile_photo.data:
            image_name = save_image(form.profile_photo.data)
            current_user.profile_photo = image_name
        database.session.commit()
        flash('Perfil atualizado com Sucesso.', 'alert-success')
        return redirect(url_for('profile'))
    elif request.method == 'GET':
        form.username.data = current_user.username
        form.email.data = current_user.email
    profile_photo = url_for('static', filename=f'profile_photos/{current_user.profile_photo}')
    return render_template('editprofile.html', profile_photo=profile_photo, form=form)


@app.route('/animes')
def animes():
    animes = Anime.query.order_by(Anime.id.desc())
    return render_template('animes.html', animes=animes)


def save_imageanime(image):
    code = secrets.token_hex(8)
    name, extension = os.path.splitext(image.filename)
    file_name = name + code + extension
    full_path = os.path.join(app.root_path, 'static/anime_photos', file_name)
    size = (400, 400)
    reduced_image = Image.open(image)
    reduced_image.thumbnail(size)
    reduced_image.save(full_path)
    return file_name


@app.route('/animes/criar', methods=['GET', 'POST'])
@login_required
def creat_anime():
    form_creatanime = FormCreatAnime()
    if form_creatanime.validate_on_submit():
        anime = Anime(name=form_creatanime.name.data, synopsis=form_creatanime.synopsis.data, creator=current_user)
        if form_creatanime.anime_photo.data:
            image_nameanime = save_imageanime(form_creatanime.anime_photo.data)
            anime.anime_photo = image_nameanime
        database.session.add(anime)
        database.session.commit()
        flash(f'Anime Criado com Sucesso', 'alert-success')
        return redirect(url_for('animes'))
    anime_photo = url_for('static', filename=f'anime_photos/{Anime.anime_photo}')
    return render_template('creat_anime.html', form_creatanime=form_creatanime, anime_photo=anime_photo)


@app.route('/anime/<anime_id>', methods=['GET', 'POST'])
def exibit_anime(anime_id):
    anime = Anime.query.get(anime_id)
    if current_user == anime.creator:
        form = FormCreatAnime()
        if request.method == 'GET':
            form.name.data = anime.name
            form.synopsis.data = anime.synopsis
        elif form.validate_on_submit():
            if form.anime_photo.data:
                image_nameanime = save_imageanime(form.anime_photo.data)
                anime.anime_photo = image_nameanime
            anime.name = form.name.data
            anime.synopsis = form.synopsis.data
            database.session.commit()
            flash('Anime Atualizado com Sucesso')
    else:
        form = None
    anime_photo = url_for('static', filename=f'anime_photos/{Anime.anime_photo}')
    return render_template('anime.html', anime=anime, form=form, anime_photo=anime_photo)


@app.route('/anime/<anime_id>/excluir', methods=['GET', 'POST'])
@login_required
def delete_anime(anime_id):
    anime = Anime.query.get(anime_id)
    if current_user == anime.creator:
        database.session.delete(anime)
        database.session.commit()
        flash('Anime Excluído com Sucesso', 'alert-danger')
        return redirect(url_for('animes'))
    else:
        abort(403)


@app.route('/episódios')
def episodes():
    episodes = Episode.query.order_by(Episode.id)
    return render_template('episodes.html', episodes=episodes)


def save_imageepisode(image):
    code = secrets.token_hex(8)
    name, extension = os.path.splitext(image.filename)
    file_name = name + code + extension
    full_path = os.path.join(app.root_path, 'static/episode_photos', file_name)
    size = (400, 400)
    reduced_image = Image.open(image)
    reduced_image.thumbnail(size)
    reduced_image.save(full_path)
    return file_name


@app.route('/episódios/criar', methods=['GET', 'POST'])
@login_required
def creat_episode():
    form_createpisode = FormCreatEpisode()
    if form_createpisode.validate_on_submit():
        episode = Episode(name=form_createpisode.name.data, classification=form_createpisode.classification.data, synopsis=form_createpisode.synopsis.data, creator_episode=current_user)
        if form_createpisode.episode_photo.data:
            image_nameepisode = save_imageepisode(form_createpisode.episode_photo.data)
            episode.episode_photo = image_nameepisode
        database.session.add(episode)
        database.session.commit()
        flash(f'Episódio Criado com Sucesso', 'alert-success')
        return redirect(url_for('episodes'))
    episode_photo = url_for('static', filename=f'episodes_photos/{Episode.episode_photo}')
    return render_template('creat_episode.html', form_createpisode=form_createpisode, episode_photo=episode_photo)


@app.route('/episódio/<episode_id>', methods=['GET', 'POST'])
def exibit_episode(episode_id):
    episode = Episode.query.get(episode_id)
    posts = Post.query.order_by(Post.id.desc())
    if current_user == episode.creator_episode:
        form_createpisode = FormCreatEpisode()
        if request.method == 'GET':
            form_createpisode.name.data = episode.name
            form_createpisode.classification.data = episode.classification
            form_createpisode.synopsis.data = episode.synopsis
        elif form_createpisode.validate_on_submit():
            if form_createpisode.episode_photo.data:
                image_nameepisode = save_imageepisode(form_createpisode.episode_photo.data)
                episode.episode_photo = image_nameepisode
            episode.name = form_createpisode.name.data
            episode.classification = form_createpisode.classification.data
            episode.synopsis = form_createpisode.synopsis.data
            database.session.commit()
            flash('Episódio Atualizado com Sucesso')
    else:
        form_createpisode = None

    if current_user.is_authenticated:
        form = FormCreatPost()
        if form.validate_on_submit():
            post = Post(title=form.title.data, body=form.body.data, author=current_user, id_episode=episode.id_episode)
            database.session.add(post)
            database.session.commit()
            flash('Comentário Feito com Sucesso', 'alert-success')
    else:
        form = None
    return render_template('episode.html', form=form, form_createpisode=form_createpisode, episode=episode, posts=posts)


@app.route('/episódio/<episode_id>/excluir', methods=['GET', 'POST'])
@login_required
def delete_episode(episode_id):
    episode = Episode.query.get(episode_id)
    if current_user == episode.creator_episode:
        database.session.delete(episode)
        database.session.commit()
        flash('Episódio Excluído com Sucesso', 'alert-danger')
        return redirect(url_for('episodes'))
    else:
        abort(403)


@app.route('/post/<post_id>', methods=['GET', 'POST'])
@login_required
def exibit_post(post_id):
    post = Post.query.get(post_id)
    if current_user == post.author:
        form = FormCreatPost()
        if request.method == 'GET':
            form.title.data = post.title
            form.body.data = post.body
        elif form.validate_on_submit():
            post.title = form.title.data
            post.body = form.body.data
            database.session.commit()
            flash('Post Atualizado com Sucesso')
    else:
        form = None
    return render_template('post.html', post=post, form=form)


@app.route('/post/<post_id>/excluir', methods=['GET', 'POST'])
@login_required
def delete_post(post_id):
    post = Post.query.get(post_id)
    if current_user == post.author:
        database.session.delete(post)
        database.session.commit()
        flash('Post Excluído com Sucesso', 'alert-danger')
        return redirect(url_for('episodes'))
    else:
        abort(403)

